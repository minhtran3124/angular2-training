import { NgModule } from '@angular/core';
// import { BrowserModule }  from '@angular/platform-browser';
// import { HashLocationStrategy, LocationStrategy } from '@angular/common';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { RouterModule, Routes } from '@angular/router';
// import { HttpModule, JsonpModule } from '@angular/http';

// import todo component
import { TodoComponent } from './todo.component';

// firebase.initializeApp(firebaseConfig);

@NgModule({
  imports: [
    // BrowserModule,
    // FormsModule,
    // ReactiveFormsModule,
    // HttpModule,
    // JsonpModule
  ],
  declarations: [
    TodoComponent
  ],
  providers: [
    // {provide: LocationStrategy, useClass: HashLocationStrategy},
  ],
  exports: [ TodoModule ]
})
export class TodoModule { }
