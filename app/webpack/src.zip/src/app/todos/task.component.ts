import { Component } from '@angular/core';
// import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
// import { Observable } from 'rxjs/Observable';

// import * as _ from "lodash";

@Component({
  // selector: 'todo-list',
  template: `<h1>Task Component</h1>`,
  styleUrls: [ 'todo.component.css' ]
})
export class TaskComponent {

  constructor() {}

}
