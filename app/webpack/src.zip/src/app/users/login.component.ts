import { Component } from '@angular/core';
// import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
// import { Observable } from 'rxjs/Observable';

// import * as _ from "lodash";

@Component({
  // selector: 'todo-list',
  template: `<h1>Login Component</h1>`
})
export class LoginComponent {

  constructor() {}

}
