//load core
import { Routes } from '@angular/router';

//load component related routers
import { PageNotFoundComponent } from '../pagenotfound/pagenotfound.component';
import { LoginComponent } from '../users/login.component';
import { SignUpComponent } from '../users/sign-up.component';
import { TodoComponent } from '../todos/todo.component';
import { TaskComponent } from '../todos/task.component';


// define const routers
export const appRoutes: Routes = [
  { path: '', redirectTo: '/todos', pathMatch: 'full' },
  { path: 'sign-in', component: LoginComponent },
  { path: 'sign-up', component: LoginComponent },
  { path: 'todos', component: TodoComponent },
  { path: 'todo/:id', component: TaskComponent },
  { path: '**', component: PageNotFoundComponent }
];
