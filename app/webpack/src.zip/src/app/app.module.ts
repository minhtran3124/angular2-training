import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';

// import Module define manual
import { AppRoutingModule } from './routers/app-routing.module';

// import AppComponent
import { AppComponent } from './app.component';

// import PageNotFound Component
import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';

// import Component related to Todo
import { TodoComponent } from './todos/todo.component';
import { TaskComponent } from './todos/task.component';

// import User Component
import { LoginComponent } from './users/login.component';
import { SignUpComponent } from './users/sign-up.component';


let authC: Array<any> = [];
let todoC: Array<any> = [];

authC = [
  TodoComponent,
  TaskComponent
];


@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  declarations: [
    AppComponent,
    // TodoComponent,
    PageNotFoundComponent,
    LoginComponent,
    SignUpComponent,
    authC
    // TaskComponent
  ],
  providers: [
    {provide: LocationStrategy, useClass: HashLocationStrategy},
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
