import { Component } from '@angular/core';

@Component({
  selector: 'dr-highlight',
  templateUrl: 'highlight.component.html'
})
export class HighlightComponent {

}
