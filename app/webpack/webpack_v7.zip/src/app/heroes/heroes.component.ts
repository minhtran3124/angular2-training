// import core module of angular 2
import { Component, OnInit } from '@angular/core';

// import hero define constructor object
import { Hero } from './hero.model';

// import hero service
import { HeroService } from './hero.service';

@Component({
  selector: 'heroes',
  templateUrl: 'heroes.component.html',
  styleUrls: [ 'heroes.component.css' ]
})
export class HeroesComponent implements OnInit {
  heroes: Hero[];

  constructor(private heroSerive: HeroService) { }

  // get list heroes using HeroService
  getHeroes(): void {
    this.heroSerive.getHeroes()
      .then(heroes => this.heroes = heroes);
  }

  ngOnInit() {
    this.getHeroes();
  }
}
