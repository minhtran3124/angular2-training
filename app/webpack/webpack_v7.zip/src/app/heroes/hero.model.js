"use strict";
//# sourceMappingURL=hero.model.js.map