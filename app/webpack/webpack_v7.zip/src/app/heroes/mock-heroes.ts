import { Hero } from './hero.model';

export var HEROES: Hero[] = [
  {id: 1, name: 'Alden'},
  {id: 2, name: 'Eagan'},
  {id: 3, name: 'Alexander'},
  {id: 4, name: 'Ciaran'},
  {id: 5, name: 'Lucas'},
  {id: 6, name: 'Cairo'},
  {id: 7, name: 'Castor'},
  {id: 8, name: 'Isaac'},
  {id: 9, name: 'Carson'},
  {id: 10, name: 'Carson'}
];
