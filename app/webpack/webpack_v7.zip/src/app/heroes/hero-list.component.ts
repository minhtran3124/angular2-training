import { Component } from '@angular/core';

import { HeroDetailComponent } from './hero-detail.component';

@Component({
  selector: 'hero-list',
  template: ``
})
export class HeroListComponent {

}
