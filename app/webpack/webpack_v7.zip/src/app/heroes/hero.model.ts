// export constructor init hero object
export interface Hero {
  id: number;
  name: string;
}
