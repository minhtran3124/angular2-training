"use strict";
exports.firebaseConfig = {
    apiKey: "AIzaSyAbih-RMrHOYApQ48kTrrfUMghf-o8RCu0",
    authDomain: "todoexample-ad9d5.firebaseapp.com",
    databaseURL: "https://todoexample-ad9d5.firebaseio.com",
    storageBucket: "todoexample-ad9d5.appspot.com",
    messagingSenderId: "71209448697"
};
//# sourceMappingURL=firebase.config.js.map