import { Injectable } from "@angular/core";
import { UUID } from 'angular2-uuid';

@Injectable()
export class UUIDService {
  uuid: string;

  generateUUID() {
    return UUID.UUID();
  }
}
