import { Injectable } from '@angular/core';
import { Headers, Http } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';

// import structure interface Todo
import { User } from '../models/user.model';

@Injectable()
export class UserService {
  private headers = new Headers({'Content-Type': 'application/json'});
  private baseUrl: string;

  constructor(private http: Http) {
      this.baseUrl = 'https://todoexample-ad9d5.firebaseio.com/heroes/';
  }

  // get all user from database
  getList(): Promise<User[]> {
    return this.http
      .get(this.baseUrl + '.json')
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError);
  }

  // get single user with key
  getUser(firebaseKey: string): Promise<User> {
    return this.http
      .get(this.baseUrl + firebaseKey + '.json')
      .toPromise()
      .then(response => {
        return response.json();
      })
      .catch(this.handleError);
  }

  // add new User object and post to database
  addNew(user: Object): Promise<User> {
    return this.http
      .post(this.baseUrl + '.json', JSON.stringify(user), {headers: this.headers})
      .toPromise()
      .then(response => {
        return response.json();
      })
      .catch(this.handleError);
  }

  removeUser(firebaseKey: string) {
    return this.http
      .delete(this.baseUrl + firebaseKey + '.json')
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError);
  }

  // handle error when have errors
  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
