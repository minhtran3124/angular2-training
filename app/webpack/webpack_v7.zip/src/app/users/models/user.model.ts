export interface User {
  firebaseKey: string;
  uuid: string;
  name: string;
}
