import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs/Observable';

import * as _ from "lodash";

// import structure interface and UserService
import { UserService } from '../services/user.service';
import { UUIDService } from '../services/id.service';
import { User } from '../models/user.model';

@Component({
  selector: 'user-component',
  templateUrl: 'user.component.html',
  styleUrls: [ 'user.component.css' ]
})
export class UserComponent implements OnInit {
  users: Array<any> = [];
  userForm: FormGroup;

  constructor(
    private userService: UserService,
    private builder: FormBuilder,
    private uuidService: UUIDService
  ) {}

  // load list users and reset form when application bootstraped
  ngOnInit() {
    this.loadList();
    this.resetForm();
  }

  updatedList(): void {
    this.users = [];
    this.loadList();
  }

  // reset form
  resetForm() {
    this.userForm = this.builder.group({
			name: [''],
      job: [''],
      age: ['']
		})
  }

  // call service to get all list users
  // return array `users`
  loadList(): void {
    this.userService
      .getList()
      .then(users => {
        for (var key in users) {
          users[key].firebaseKey = key;
          this.users.push(users[key]);
          console.log('load list successfully !!!');
        }
      });
  }

  // get single user with key
  // return user map with key firebase : object
  getSingleUser(firebaseKey: string): void {
    this.userService
      .getUser(firebaseKey)
      .then((user) => {
        return user;
      });
  }

  // add new user
  // `addNew` service return user key of firebase : string
  // `getUser` service return `user` object and push it to array `users`
  addNewUser(user: User): any {
    this.userService
      .addNew(user)
      .then(firebaseKey => {
        user.firebaseKey = firebaseKey.name;
        this.users.push(user);
        console.log('add new user successfully !!!');
        console.log(this.users);
      });
  }

  // call function add new user and reset form to re-add new user
  onSubmit() {
    this.userForm.value.uuid = this.uuidService.generateUUID();
    this.addNewUser(this.userForm.value);
    this.resetForm();
  }

  // remove user with firebase key
  removeUser(user: User): void {
    this.userService
      .removeUser(user.firebaseKey)
      .then(() => {
        let index = this.users.indexOf(user);
        this.users.splice(index, 1);
        console.log('remove user successfully !!!');
      });
  }
}
