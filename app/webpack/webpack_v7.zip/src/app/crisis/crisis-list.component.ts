import { Component } from '@angular/core';

@Component({
  selector: 'crisis-list',
  templateUrl: 'crisis-list.component.html'
})
export class CrisisListComponent {

}
