import { Injectable } from '@angular/core';
import { Observable, Subject } from "rxjs/Rx";
import { AngularFireDatabase } from 'angularfire2';

@Injectable()
export class CrisisService {

  constructor(private db: AngularFireDatabase) { }
}
