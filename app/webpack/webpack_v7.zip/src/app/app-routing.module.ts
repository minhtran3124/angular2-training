// import core module
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

// import Directive Component
import { HighlightComponent } from './directives-attribute/highlight.component';
import { FilmParentComponent } from './directives-example/film-parent.component';

// import CrisisList Component
import { CrisisListComponent } from './crisis/crisis-list.component';

// import PageNotFound Component
import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';

// import Heroes Component
import { HeroesComponent } from './heroes/heroes.component';
import { HeroDetailComponent } from './heroes/hero-detail.component';

// import TodoComponent
import { UserComponent } from './users/components/user.component';

export const appRoutes: Routes = [
  { path: '',                 redirectTo: '/heroes',                pathMatch: 'full'},
  { path: 'highlight',        component: HighlightComponent },
  { path: 'film',             component: FilmParentComponent },
  { path: 'crisis-center',    component: CrisisListComponent },
  { path: 'heroes',           component: HeroesComponent },
  { path: 'hero/:id',         component: HeroDetailComponent },
  { path: 'users',            component: UserComponent },
  { path: '**',               component: PageNotFoundComponent }
];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}
