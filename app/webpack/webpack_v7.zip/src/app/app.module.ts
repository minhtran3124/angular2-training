import { NgModule } from '@angular/core';
import { BrowserModule }  from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule, JsonpModule } from '@angular/http';

/*load AppComponent*/
import { AppComponent } from './app.component';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';

/*load component for example about Structural Directives [NgFor Directive]*/
import { FilmChildComponent } from './directives-example/film-child.component';
import { FilmParentComponent } from './directives-example/film-parent.component';
import { HighlightDirective } from './directives-attribute/highlight.directive';
import { HighlightComponent } from './directives-attribute/highlight.component';

/*load CrisisList Component*/
import { CrisisListComponent } from './crisis/crisis-list.component';

/*load PageNotFound Component*/
import { PageNotFoundComponent } from './pagenotfound/pagenotfound.component';

/*imports Heros Component feature*/
import { HeroesComponent } from './heroes/heroes.component';
import { HeroService } from './heroes/hero.service';
import { HeroDetailComponent } from './heroes/hero-detail.component';

/*import firebaseConfig and packages related to FireBase*/
import * as firebase from 'firebase';
import { firebaseConfig } from './firebase/firebase.config';
import { AngularFireModule } from 'angularfire2/index';

/*import TodoComponent */
import { UserComponent } from './users/components/user.component';
import { UserService } from './users/services/user.service';
import { UUIDService } from './users/services/id.service';

firebase.initializeApp(firebaseConfig);

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpModule,
    JsonpModule
  ],
  declarations: [
    AppComponent,
    FilmChildComponent,
    FilmParentComponent,
    HighlightDirective,
    HighlightComponent,
    CrisisListComponent,
    PageNotFoundComponent,
    HeroesComponent,
    HeroDetailComponent,
    UserComponent
  ],
  providers: [
    HeroService,
    {provide: LocationStrategy, useClass: HashLocationStrategy},
    UserService,
    UUIDService
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
