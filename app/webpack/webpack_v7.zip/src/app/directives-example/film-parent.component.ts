import { Component } from '@angular/core';

@Component({
  selector: 'film-parent',
  template: `
    <film-child
      *ngFor="let episode of episodes; let i = index; let isOdd = odd"
      [episode]="episode"
      [ngClass]="{ odd: isOdd }">
        {{ i+1 }}. {{ episode.title }}
    </film-child>

    <hr />

    <template ngFor [ngForOf]="episodes" let-episode let-i="index" let-isOdd="odd">
      <film-child
        [episode]="episode"
        [ngClass]="{odd : isOdd}">
          {{ i+1 }}. {{ episode.title }}
      </film-child>
    </template>
  `
})
export class FilmParentComponent {
  episodes: any[] = [
    { title: 'Winter Is Coming', director: 'Tim Van Patten', id: 0 },
    { title: 'The Kingsroad', director: 'Tim Van Patten', id: 1 },
    { title: 'Lord Snow', director: 'Brian Kirk', id: 2 },
    { title: 'Cripples, Bastards, and Broken Things', director: 'Brian Kirk', id: 3 },
    { title: 'The Wolf and the Lion', director: 'Brian Kirk', id: 4 },
    { title: 'A Golden Crown', director: 'Daniel Minahan', id: 5 },
    { title: 'You Win or You Die', director: 'Daniel Minahan', id: 6 },
    { title: 'The Pointy End', director: 'Daniel Minahan', id: 7 }
  ];
}
