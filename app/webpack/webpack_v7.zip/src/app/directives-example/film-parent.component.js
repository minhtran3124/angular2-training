"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var FilmParentComponent = (function () {
    function FilmParentComponent() {
        this.episodes = [
            { title: 'Winter Is Coming', director: 'Tim Van Patten', id: 0 },
            { title: 'The Kingsroad', director: 'Tim Van Patten', id: 1 },
            { title: 'Lord Snow', director: 'Brian Kirk', id: 2 },
            { title: 'Cripples, Bastards, and Broken Things', director: 'Brian Kirk', id: 3 },
            { title: 'The Wolf and the Lion', director: 'Brian Kirk', id: 4 },
            { title: 'A Golden Crown', director: 'Daniel Minahan', id: 5 },
            { title: 'You Win or You Die', director: 'Daniel Minahan', id: 6 },
            { title: 'The Pointy End', director: 'Daniel Minahan', id: 7 }
        ];
    }
    return FilmParentComponent;
}());
FilmParentComponent = __decorate([
    core_1.Component({
        selector: 'film-parent',
        template: "\n    <film-child\n      *ngFor=\"let episode of episodes; let i = index; let isOdd = odd\"\n      [episode]=\"episode\"\n      [ngClass]=\"{ odd: isOdd }\">\n        {{ i+1 }}. {{ episode.title }}\n    </film-child>\n\n    <hr />\n\n    <template ngFor [ngForOf]=\"episodes\" let-episode let-i=\"index\" let-isOdd=\"odd\">\n      <film-child\n        [episode]=\"episode\"\n        [ngClass]=\"{odd : isOdd}\">\n          {{ i+1 }}. {{ episode.title }}\n      </film-child>\n    </template>\n  "
    }),
    __metadata("design:paramtypes", [])
], FilmParentComponent);
exports.FilmParentComponent = FilmParentComponent;
//# sourceMappingURL=film-parent.component.js.map