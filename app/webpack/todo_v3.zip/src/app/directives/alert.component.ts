import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'login-component',
    templateUrl: 'login-component.component.html',
    styleUrls: ['login-component.component.css']
})
export class AlertComponent {

}
