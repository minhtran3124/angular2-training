export interface Todo {
  id: string;
  todo_name: string;
  id_user: string;
}
