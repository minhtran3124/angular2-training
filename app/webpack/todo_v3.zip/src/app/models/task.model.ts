export interface Task {
  id: string;
  id_todo: string;
  name: string;
  status: Boolean;
  created: Date;
}
