import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'auth-component',
    templateUrl: 'auth.component.html',
    styleUrls: ['auth.component.css']
})
export class AuthComponent {

}
